/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
// const links = document.querySelectorAll('#section');
// links.forEach(link => {
//     link.addEventListener('click', () => {
//         links.forEach((link) =>{
//             links.className = "navbar__menu"   
//         });
       
//         link.classList.add("change");
//     });
// });

// const links = document.getElementById('nav');

// (function () {
//     window.NAV = {
//         $body: $("body"),
//         $subMenus: $(".subMenu"),
//         toggle: function (e) {
//             e.preventDefault();
//             NAV.$body.toggleClass("mainMenu-is-open");
//         },
//         bindEvents: function () {
//             $(".js-togglesOffCanvas").on("click", NAV.toggle);
//         },
//         init: function () {
//             NAV.bindEvents();
//         }
//     }
// })();
// NAV.init();




// build the nav


// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


window.onscroll = function () { scrollFunction() };

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("navbar").style.top = "0";
    } else {
        document.getElementById("navbar").style.top = "-50px";
    }
}